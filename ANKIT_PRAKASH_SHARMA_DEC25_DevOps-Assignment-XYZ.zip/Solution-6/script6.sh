#!/bin/bash
read -p "Enter marks (0-100): " marks
if [ "$marks" -ge 90 ]; then
    echo "Grade A+"
elif [ "$marks" -ge 75 ]; then
    echo "Grade A"
elif [ "$marks" -ge 50 ]; then
    echo "Grade B"
else
    echo "Fail"
fi
