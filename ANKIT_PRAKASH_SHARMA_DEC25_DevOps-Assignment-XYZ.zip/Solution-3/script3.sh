#!/bin/bash
read -p "Enter Name: " name
read -p "Enter Age: " age
read -p "Enter State: " state
read -p "Enter Designation: " designation
echo "Name: $name | Age: $age | State: $state | Designation: $designation"
