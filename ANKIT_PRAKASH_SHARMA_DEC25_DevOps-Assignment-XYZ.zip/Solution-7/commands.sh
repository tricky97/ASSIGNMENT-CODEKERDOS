#!/bin/bash
# User and group creation
sudo useradd -m alice
sudo useradd -m bob
sudo passwd alice
sudo passwd bob

sudo groupadd devteam
sudo usermod -aG devteam alice
sudo usermod -aG devteam bob

sudo mkdir -p /dev/shared
sudo chown :devteam /dev/shared
sudo chmod 770 /dev/shared
