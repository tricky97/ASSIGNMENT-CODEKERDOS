#!/bin/bash
read -p "Enter first number: " num1
read -p "Enter second number: " num2
if [ "$num1" -gt "$num2" ]; then
    echo "First number is greater"
elif [ "$num2" -gt "$num1" ]; then
    echo "Second number is greater"
else
    echo "Both numbers are equal"
fi
