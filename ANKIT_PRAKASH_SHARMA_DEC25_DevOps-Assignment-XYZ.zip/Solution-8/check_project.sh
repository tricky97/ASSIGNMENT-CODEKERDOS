#!/bin/bash
echo "Current Date and Time: $(date)"
echo "Files in project directory:"
ls -l /home/tricky/project
echo "Disk usage of home directory:"
du -sh ~/
