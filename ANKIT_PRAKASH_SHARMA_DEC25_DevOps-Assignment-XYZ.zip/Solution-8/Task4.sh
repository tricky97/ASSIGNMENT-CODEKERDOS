#Task-4: Collaborative script
cd /home/tricky/project
nano deploy.sh


#Inside deploy.sh

#/bin/bash
echo "Deploying project..."
date

chmod 770 deploy.sh