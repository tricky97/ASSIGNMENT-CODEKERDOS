#/bin/bash

#Task-6: View logs
tail -n 10 /var/log/syslog


#Search SSH logs:

grep ssh /var/log/syslog