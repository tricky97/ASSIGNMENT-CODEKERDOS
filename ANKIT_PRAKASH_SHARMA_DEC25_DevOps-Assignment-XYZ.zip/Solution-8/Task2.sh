#/bin/bash

#Task-2: Manage file permissions
chmod 600 app.log
chmod 644 config.cfg
chmod 666 data.csv

ls -l