#/bin/bash
#Setup project directory
mkdir -p /home/tricky/project
cd /home/tricky/project

touch app.log config.cfg data.csv
echo "mode=production" > config.cfg
cat config.cfg
