#/bin/bash
#Task-5: Process monitoring
ps aux | grep ssh


#Find PID:

ps aux | grep sshd


#Kill safely:

sudo kill <PID>