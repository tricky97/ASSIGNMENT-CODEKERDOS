#/bin/bash

#Task-3: User and group management
sudo useradd -m devuser
sudo groupadd developers
sudo usermod -aG developers devuser

sudo chown :developers /home/tricky/project
sudo chmod 770 /home/tricky/project