#!/bin/bash
read -p "Enter your name: " name
echo "Welcome, $name"
