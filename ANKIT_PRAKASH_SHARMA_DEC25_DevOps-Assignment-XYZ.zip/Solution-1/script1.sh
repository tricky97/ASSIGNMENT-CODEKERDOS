#!/bin/bash
echo "Hello World"
echo "Hello Saurabh"
echo "Hello DevOps"
