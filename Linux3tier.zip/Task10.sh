#!/bin/bash

REPORT="/var/log/custom/system_report.log"

echo "------ $(date) ------" >> $REPORT

echo "Apache status:" >> $REPORT
systemctl is-active apache2 >> $REPORT

echo "MariaDB status:" >> $REPORT
systemctl is-active mariadb >> $REPORT

echo "Port 80 status:" >> $REPORT
ss -tuln | grep :80 >> $REPORT

echo "Disk usage:" >> $REPORT
df -h / >> $REPORT

echo "Memory usage:" >> $REPORT
free -h >> $REPORT

echo "------------------------" >> $REPORT
