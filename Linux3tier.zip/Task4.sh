#!/bin/bash

LOG_DIR="/var/log/custom"
LOG_FILE="$LOG_DIR/service_status.log"

mkdir -p $LOG_DIR

echo "------ $(date) ------" >> $LOG_FILE

if systemctl is-active --quiet apache2; then
    echo "Apache: RUNNING" >> $LOG_FILE
else
    echo "Apache: STOPPED" >> $LOG_FILE
fi

if systemctl is-active --quiet mariadb; then
    echo "MariaDB: RUNNING" >> $LOG_FILE
else
    echo "MariaDB: STOPPED" >> $LOG_FILE
fi


#crontab -e
#*/5 * * * * /opt/scripts/service_check.sh
