#!/bin/bash

THRESHOLD=80
LOG="/var/log/custom/disk_warning.log"

USAGE=$(df / | awk 'NR==2 {print $5}' | tr -d '%')

if [ "$USAGE" -gt "$THRESHOLD" ]; then
    echo "$(date): Disk usage is above $THRESHOLD% (Current: $USAGE%)" >> $LOG
fi
sudo chmod +x /opt/scripts/app_check.sh
