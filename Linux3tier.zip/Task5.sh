#!/bin/bash

SRC="/var/log"
BACKUP="/var/log/backup"

mkdir -p $BACKUP

find $SRC -type f -mmin -60 -name "*.log" -exec cp {} $BACKUP \;
find $SRC -type f -mmin -60 -name "*.log" -exec rm -f {} \;
sudo chmod +x /opt/scripts/log_cleanup.sh
