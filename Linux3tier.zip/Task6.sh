crontab -e
0 * * * * /opt/scripts/log_cleanup.sh
