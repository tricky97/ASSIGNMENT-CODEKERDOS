#!/bin/bash

BACKUP_DIR="/var/backups/db"
DATE=$(date +%F-%H-%M)

mkdir -p $BACKUP_DIR

mysqldump -u root --all-databases > $BACKUP_DIR/db_backup_$DATE.sql
sudo chmod +x /opt/scripts/db_backup.sh
