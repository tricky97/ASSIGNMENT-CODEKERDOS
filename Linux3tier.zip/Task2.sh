systemctl status apache2
systemctl status mariadb
