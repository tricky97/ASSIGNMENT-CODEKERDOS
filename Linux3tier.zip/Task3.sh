#!/bin/bash

echo "Service Health Check"

if systemctl is-active --quiet apache2; then
    echo "Apache: RUNNING"
else
    echo "Apache: STOPPED"
fi

if systemctl is-active --quiet mariadb; then
    echo "MariaDB: RUNNING"
else
    echo "MariaDB: STOPPED"
fi
