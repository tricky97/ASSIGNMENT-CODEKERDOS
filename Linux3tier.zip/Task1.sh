sudo systemctl stop apache2 mariadb
sudo apt purge -y apache2 mariadb-server
sudo apt autoremove -y
sudo rm -rf /var/www/app

sudo ss -tulnp | grep :80
