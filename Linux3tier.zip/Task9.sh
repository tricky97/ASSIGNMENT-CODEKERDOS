#!/bin/bash

LOG="/var/log/custom/app_status.log"

if curl -s http://localhost:80 > /dev/null; then
    echo "$(date): Application is reachable" >> $LOG
else
    echo "$(date): Application is DOWN" >> $LOG
fi
sudo chmod +x /opt/scripts/app_check.sh
